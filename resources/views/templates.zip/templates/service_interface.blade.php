

namespace App\Contracts\Services;

interface {{ $name }}ServiceInterface
{


}
