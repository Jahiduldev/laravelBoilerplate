
namespace App\Contracts\Repositories;

interface {{ $name }}RepositoryInterface
{

}
